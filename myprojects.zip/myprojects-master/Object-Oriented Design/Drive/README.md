# drive_3380
Project progress available at https://server.1337ersprime.com when updated.

## ABOUT

## INFO
Certain files are not included in this repo because of passwords and other info that should not be publicly available (Notably dbconf.php in /login/dbconf.php--See dbconf-sample.php for sample version). Google Maps API key redacted to avoid mass requests and GitGuardian emails

Login System modified from: https://github.com/therecluse26/PHP-Login
