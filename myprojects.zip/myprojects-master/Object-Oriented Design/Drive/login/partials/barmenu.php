<?php

// Define the buttons in the menu bar
$barmenu = array(
    "Home" => "",
    "Drive" => "drive.php",
    "About Us" => "about.php",
    "Contact" => "contact.php"
);
