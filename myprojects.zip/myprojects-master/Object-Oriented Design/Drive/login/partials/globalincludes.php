<?php
// Global Includes
echo '<script src="'.$this->base_url.'/vendor/components/jquery/jquery.min.js" type="application/javascript"></script>
      <script src="'.$this->base_url.'/vendor/components/bootstrap/js/bootstrap.min.js" type="application/javascript"></script>
      <link href="'.$this->base_url.'/vendor/components/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
      <link href="'.$this->base_url.'/login/css/main.css" rel="stylesheet" media="screen">';
