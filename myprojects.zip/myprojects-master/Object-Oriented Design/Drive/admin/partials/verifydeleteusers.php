<table id="userlist" class="table table-sm">
  <thead>
    <th></th>
    <th>Username</th>
    <th>Email</th>
    <th>Timestamp</th>
  </thead>
</table>

<?php include "usermanagementmodals.html";?>

<script type="application/javascript" src="js/userverification.js"></script>
