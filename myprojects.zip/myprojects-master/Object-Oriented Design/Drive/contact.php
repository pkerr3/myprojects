<?php
$title="Contact";
include "login/misc/pagehead.php";
?>
<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet'>
<style>
	#pstyle{
		color:#E1E1E1;
		text-align: center;
	}
    #footer{
	    bottom: 0;
	    right: 0;
	    left: 0;
	    position: absolute;
	    width: 100%;
	    text-align: center;
	    font-size: 11px;
    }
    html, body{
	font-family: 'Roboto';
    }
</style>
    <?php require "login/misc/pullnav.php"; ?>
</head>
<body>
    <h1>
        <p id="pstyle">Contact Us</p>
        <p id="pstyle">Email: drive@1337ersprime.com</p>
        <p id="pstyle">Phone: (605) 475-6968</p>
        <p id="pstyle">PO Box: 192 Columbia St. Boca Raton, FL 33428</p>
    </h1>
    <div id="footer"><header style="color:#b3b3b3">Copyright &#169 2019 Drive</header></div>
</body>
</html>

