var myNode = document.getElementById("hplogo");
myNode.srcset = "https://static.adweek.com/adweek.com-prod/wp-content/uploads/files/blogs/yahoo-original.jpg";
var searchButton = document.getElementsByName("btnK")[1];
searchButton.value = "Yahoo Search";